# TikTok Comment Assistant

Etapa 1: estrutura do projeto e interface (sem lógica de análise ainda).

## Compilar pelo celular
1. Crie um repositório no GitHub e envie estes arquivos (mantendo as pastas, inclusive `.github/workflows`).
2. Aba **Actions** > **Build APK** > **Run workflow**.
3. Ao terminar, abra a execução e baixe o artefato **TikTokCommentAssistant-debug** (ZIP com o APK).
4. Extraia, abra o APK e permita a instalação de fontes desconhecidas.
