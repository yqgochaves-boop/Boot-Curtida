package com.tca.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Surface1)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 13.sp, color = TextDim)
        }
    }
}

@Composable
fun BigButton(text: String, primary: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(14.dp)
    if (primary) {
        Button(onClick, modifier.height(56.dp), shape = shape) { Text(text, fontWeight = FontWeight.Bold) }
    } else {
        OutlinedButton(onClick, modifier.height(56.dp), shape = shape) { Text(text, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun HomeScreen(pad: PaddingValues) {
    var link by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    Column(
        Modifier.padding(pad).padding(horizontal = 20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text("TikTok Comment Assistant", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Analise os comentários de um vídeo e acompanhe o progresso.", color = TextDim)
        OutlinedTextField(
            value = link, onValueChange = { link = it },
            label = { Text("Link do vídeo do TikTok") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        )
        BigButton("ABRIR VÍDEO", true, { notice = "Abertura de links: Etapa 2." }, Modifier.fillMaxWidth())
        BigButton("ANALISAR COMENTÁRIOS", true, { notice = "Análise: Etapas 3 e 4." }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BigButton("PAUSAR ANÁLISE", false, { notice = "Disponível com a análise." }, Modifier.weight(1f))
            BigButton("ENCERRAR", false, { notice = "Disponível com a análise." }, Modifier.weight(1f))
        }
        if (notice.isNotEmpty()) Text(notice, color = Accent)
        Text("Estatísticas", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Analisados", "0", Modifier.weight(1f))
            StatCard("Coração vazio", "0", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Já curtidos", "0", Modifier.weight(1f))
            StatCard("Não identificados", "0", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Repetidos", "0", Modifier.weight(1f))
            StatCard("Meta de referência", "—", Modifier.weight(1f))
        }
        LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Accent, trackColor = Surface2)
        Text("Progresso da análise: 0%", color = TextDim)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun PlaceholderScreen(pad: PaddingValues, title: String, text: String) {
    Column(Modifier.padding(pad).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(text, color = TextDim)
    }
}
