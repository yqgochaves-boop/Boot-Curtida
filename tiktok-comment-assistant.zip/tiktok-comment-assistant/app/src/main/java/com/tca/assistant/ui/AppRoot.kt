package com.tca.assistant.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

@Composable
fun AppRoot() {
    TcaTheme {
        var tab by remember { mutableIntStateOf(0) }
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Surface1) {
                    val items = listOf("Início" to Icons.Filled.Home, "Análises" to Icons.Filled.Search, "Histórico" to Icons.Filled.DateRange)
                    items.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent, selectedTextColor = Accent,
                                indicatorColor = Surface2
                            )
                        )
                    }
                }
            }
        ) { pad ->
            when (tab) {
                0 -> HomeScreen(pad)
                1 -> PlaceholderScreen(pad, "Análises", "Nenhuma análise em andamento. Os resultados aparecem aqui nas próximas etapas.")
                else -> PlaceholderScreen(pad, "Histórico", "Nenhum registro ainda. O histórico chega na Etapa 6.")
            }
        }
    }
}
