package com.tca.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0E0E10)
val Surface1 = Color(0xFF1A1A1E)
val Surface2 = Color(0xFF26262B)
val Accent = Color(0xFFFE2C55)
val TextDim = Color(0xFFA0A0A8)

@Composable
fun TcaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = Color.White,
            background = Bg, onBackground = Color.White,
            surface = Surface1, onSurface = Color.White,
            surfaceVariant = Surface2, onSurfaceVariant = TextDim,
            outline = Color(0xFF3A3A40)
        ),
        content = content
    )
}
